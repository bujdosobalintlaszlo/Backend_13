const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize
(
    process.env.DB_NAME,
    process.env.DB_USERNAME,
    process.env.DB_PASSWORD,

    {
        host: process.env.DB_HOST,
        dialect: process.env.DB_DIALECT,
        logging: false,
    }
)

try
{
    sequelize.authenticate();
    console.log("Kesz az adatbazis");
}
catch(error)
{
    console.log(error.message);
}

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

const { Jatekos, Csapat, Logo, Szurkolo } = require("../models")(sequelize, DataTypes);

db.jatekos = Jatekos;
db.csapat = Csapat;
db.logo = Logo;
db.szurkolo = Szurkolo;
db.sequelize.sync({ alter: false });

module.exports = db;