module.exports = (sequelize, DataTypes) =>
    {
        const Jatekos = require("../models/jatekos")(sequelize, DataTypes);
        const Csapat = require("../models/csapat")(sequelize, DataTypes)
        const Logo = require("../models/logo")(sequelize, DataTypes);
        const Szurkolo = require("../models/szurkolo")(sequelize, DataTypes);
    
        Csapat.hasOne(Logo, {
            foreignKey: "csapatID",
        });

        Csapat.hasMany(Jatekos, {
            foreignKey: "csapatID",
        });

        Szurkolo.belongsToMany(Csapat,{
            foreignKey: "SzurkoloSzigSzam",
            through: "Szurkol",
        });
    
        return { Jatekos, Csapat, Logo, Szurkolo };
    }