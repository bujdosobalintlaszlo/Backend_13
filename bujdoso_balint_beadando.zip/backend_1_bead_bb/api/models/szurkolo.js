const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) =>
{
    class Szurkolo extends Model {};

    Szurkolo.init
    (
        {
            szigSzam:
            {
                type: DataTypes.INTEGER,
                primaryKey: true,
            },

            nev:
            {
                type: DataTypes.STRING,
            },

            kor:
            {
                type: DataTypes.INTEGER,
            },

            szuletesiDatum:
            {
                type: DataTypes.DATE,
                defaultValue: new Date("2005-07-04"),
            },

            nem:
            {
                type: DataTypes.ENUM,
                values: ['Ferfi', 'No'],
                defaultValue: 'Ferfi'
            },
        },

        {
            sequelize,
            modelName: "Szurkolo",
            timestamps: false,
            freezeTableName: true
        }
    )

    return Szurkolo;
}