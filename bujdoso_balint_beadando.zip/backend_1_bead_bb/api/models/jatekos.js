const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) =>
{
    class Jatekos extends Model {};

    Jatekos.init
    (
        {
            szigSzam:
            {
                type: DataTypes.INTEGER,
                primaryKey: true,
            },

            szuletesiDatum:
            {
                type: DataTypes.DATE,
                defaultValue: new Date('2005-07-04'),
            },

            golokSzama:
            {
                type: DataTypes.INTEGER,
                defaultValue: 0,
            },

            magassag:
            {
                type: DataTypes.FLOAT,
            },

            nev:
            {
                type: DataTypes.STRING,
            },

            suly:
            {
                type: DataTypes.FLOAT,
            },

            kor:
            {
                type: DataTypes.INTEGER,
                defaultValue: 18,
            },

            igazolasIdeje: {
                type: DataTypes.DATE,
            },

        },

        {
            sequelize,
            modelName: "Jatekos",
            timestamps: false,
            freezeTableName: true
        }
    )

    return Jatekos;
}