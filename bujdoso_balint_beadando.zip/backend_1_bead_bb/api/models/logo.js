const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) =>
{
    class Logo extends Model {};

    Logo.init
    (
        {
            figura:
            {
                type: DataTypes.STRING,
                unique: true,
                primaryKey: true,
            },

            foSzin:
            {
                type: DataTypes.STRING,
                unique: true,
                primaryKey: true,
            },

            keszitoNeve:
            {
                type: DataTypes.STRING,
            },

            elkeszulesDatum:
            {
                type: DataTypes.DATE,
                defaultValue: new Date("2000-07-04"),
            },
        },

        {
            sequelize,
            modelName: "Logo",
            timestamps: false,
            freezeTableName: true
        }
    )

    return Logo;
}