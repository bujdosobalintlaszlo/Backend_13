const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) =>
{
    class Csapat extends Model {};

    Csapat.init
    (
        {
            azonosito:
            {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },

            nev:
            {
                type: DataTypes.STRING,
            },

            klubtagokSzama:
            {
                type: DataTypes.INTEGER,
                defaultValue: 0,
            }
        },

        {
            sequelize,
            modelName: "Csapat",
            timestamps: false,
            freezeTableName: true
        }
        
    )

    return Csapat;
}